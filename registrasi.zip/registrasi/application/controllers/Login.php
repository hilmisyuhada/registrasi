<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('M_data');
        $this->load->library('session');
         $this->load->library('pagination');
        $this->load->library('form_validation');
    }

   public function index() {
    $this->load->library('pagination');
    $this->load->model('m_data');

    // Konfigurasi pagination
    $config['base_url'] = site_url('login/index'); // URL halaman
    $config['total_rows'] = $this->m_data->count_all1(); // Jumlah total data
    $config['per_page'] = 5; // Jumlah data per halaman
    $config['uri_segment'] = 3; // Segment URI untuk nomor halaman

    // Kustomisasi tautan halaman
    $config['attributes'] = array('class' => 'page-link');
    $config['full_tag_open'] = '<nav aria-label="Page navigation example"><ul class="pagination justify-content-center">';
    $config['full_tag_close'] = '</ul></nav>';
    $config['first_link'] = 'First';
    $config['last_link'] = 'Last';
    $config['first_tag_open'] = '<li class="page-item">';
    $config['first_tag_close'] = '</li>';
    $config['prev_link'] = '&laquo';
    $config['prev_tag_open'] = '<li class="page-item">';
    $config['prev_tag_close'] = '</li>';
    $config['next_link'] = '&raquo';
    $config['next_tag_open'] = '<li class="page-item">';
    $config['next_tag_close'] = '</li>';
    $config['last_tag_open'] = '<li class="page-item">';
    $config['last_tag_close'] = '</li>';
    $config['cur_tag_open'] = '<li class="page-item active"><a href="#" class="page-link">';
    $config['cur_tag_close'] = '</a></li>';
    $config['num_tag_open'] = '<li class="page-item">';
    $config['num_tag_close'] = '</li>';

    // Inisialisasi library pagination
    $this->pagination->initialize($config);

    // Ambil data sesuai dengan segment URI
    $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

    // Ambil kata kunci pencarian dari form
    $search = $this->input->get('search');

    // Ambil data sesuai pencarian dan pagination
    $data['peserta'] = $this->m_data->fetch_data1($config['per_page'], $page, $search);
    $data['links'] = $this->pagination->create_links();

    // Load view
    $this->load->view('v_list', $data);
}



    public function lgin() {
        $this->load->view('v_login');
    }

    public function regis() {
        $this->load->view('v_reg');
    }

   public function daftar() {
    // Retrieve form data
    $pilihan = $this->input->post('pilihan');
    $nama_gelar = $this->input->post('nama_gelar');
    $ttl = $this->input->post('ttl');
    $profesi = $this->input->post('profesi');
    $alamat = $this->input->post('alamat');
    $no_wa = $this->input->post('no_wa');
    $email = $this->input->post('email');

    // Add 'https://wa.me/' in front of the phone number
    $no_wa_link = 'https://wa.me/' . $no_wa;

    // Configure file upload
    $config['upload_path'] = './path/';
    $config['allowed_types'] = 'gif|jpg|png|pdf';
    $config['max_size'] = 2048;

    $this->load->library('upload', $config);

    if ($this->upload->do_upload('bukti_tf')) {
        // File upload successful
        $upload_data = $this->upload->data();

        // Prepare data array
        $data = array(
            'pilihan' => $pilihan,
            'nama_gelar' => $nama_gelar,
            'ttl' => $ttl,
            'profesi' => $profesi,
            'alamat' => $alamat,
            'no_wa' => $no_wa_link,
            'email' => $email,
            'tgl_registrasi' => date('Y-m-d'), // Current timestamp
            'status' => 'invalid',
            'bukti_tf' => $upload_data['file_name'] // Simpan nama file dalam database
        );

        // Check if data already exists based on nama_gelar, email, or no_wa
        $existing_data = $this->M_data->get_by_columns('tb_registrasi', array(
            'nama_gelar' => $nama_gelar,
            'email' => $email,
            'no_wa' => $no_wa
        ));

        if ($existing_data) {
            // Data already exists, return error response
            echo json_encode(array('status' => 'error', 'message' => 'Data dengan nama, email, atau nomor Whatsapp yang sama sudah terdaftar.'));
            return;
        }

        // Insert data into database
        $table = 'tb_registrasi';
        $insert_result = $this->M_data->tambah_data($data, $table);

        if ($insert_result === true) {
            // Jika insert berhasil
            echo json_encode(array('status' => 'success'));
        } else {
            // Jika insert gagal
            echo json_encode(array('status' => 'error', 'message' => 'Gagal menyimpan data.'));
        }
    } else {
        // Handle upload error
        $error = $this->upload->display_errors();
        echo json_encode(array('status' => 'error', 'message' => $error));
    }
}


    public function masuk() {
        $email = $this->input->post('email');
        $password = $this->input->post('password');

        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('message', array('type' => 'error', 'text' => validation_errors()));
            redirect('login/lgin');
        } else {
            $user = $this->M_data->cek_login($email, $password);

            if ($user) {
                $data_session = array(
                    'id_user' => $user['id_user'],
                    'nama' => $user['nama'],
                    'email' => $user['email'],
                    'level' => $user['level']
                );
                $this->session->set_userdata($data_session);

                $this->session->set_flashdata('message', array('type' => 'success', 'text' => 'Login berhasil!', 'redirect_url' => base_url($user['level'] == 'Admin' ? 'admin' : 'peserta')));
                redirect('login/lgin');
            } else {
                $this->session->set_flashdata('message', array('type' => 'error', 'text' => 'Login gagal. Periksa kembali username dan password Anda. Jika masih bermasalah,silahkan hubungi helpdesk !'));
                redirect('login/lgin');
            }
        }
    }

    public function logout() {
        $this->session->sess_destroy();
        redirect('login/lgin');
    }
}
