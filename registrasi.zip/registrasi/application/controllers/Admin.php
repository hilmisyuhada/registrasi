<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
 		public function __construct() {
        parent::__construct();
        check_login();
        $this->load->model('M_data');
        $this->load->helper('url');
         $this->load->library('upload');
        $this->load->library('session');
        $this->load->library('pagination'); // Load library pagination
        $this->load->library('form_validation');
       
}
public function index() {

     $this->load->view('admin/v_header');
     $this->load->view('admin/v_index');
    }
    // application/controllers/Admin.php

public function valid() {
        $this->load->library('pagination');

        // Konfigurasi pagination
        $config['base_url'] = base_url('admin/valid'); // URL halaman
        $config['total_rows'] = $this->db->count_all('tb_validasi'); // Jumlah total data
        $config['per_page'] = 5; // Jumlah data per halaman
        $config['uri_segment'] = 3; // Segment URI untuk nomor halaman

        // Kustomisasi tautan halaman
        $config['attributes'] = array('class' => 'page-link');
        $config['full_tag_open'] = '<nav aria-label="Page navigation example"><ul class="pagination justify-content-center">';
        $config['full_tag_close'] = '</ul></nav>';
        $config['first_link'] = 'First';
        $config['last_link'] = 'Last';
        $config['first_tag_open'] = '<li class="page-item">';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = '&laquo';
        $config['prev_tag_open'] = '<li class="page-item">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = '&raquo';
        $config['next_tag_open'] = '<li class="page-item">';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li class="page-item">';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="page-item active"><a href="#" class="page-link">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li class="page-item">';
        $config['num_tag_close'] = '</li>';

        // Inisialisasi library pagination
        $this->pagination->initialize($config);

        // Ambil data sesuai dengan segment URI
        $offset = $this->uri->segment(3, 0);

        // Ambil kata kunci pencarian dari form
        $search = $this->input->get('search');

        // Ambil tanggal dari form
        $tanggal = $this->input->get('tanggal');

        // Ambil status validasi dari form
        $status = $this->input->get('status');

        // Query untuk mengambil data validasi dengan filter
        $this->db->select('*');
        if ($status) {
            $this->db->where('status', $status);
        }
        if ($tanggal) {
            $this->db->where('tgl_validasi', $tanggal);
        }
        if ($search) {
            $this->db->group_start();
            $this->db->like('nama', $search);
            $this->db->or_like('no_wa', $search);
            $this->db->group_end();
        }

        $this->db->order_by('tgl_validasi', 'DESC');
        $this->db->limit($config['per_page'], $offset);
        $data['valid'] = $this->db->get('tb_validasi')->result();

        // Query untuk menghitung total data berdasarkan status
        $this->db->where('status', 'sudah ada akun');
        $data['total_sudah_ada_akun'] = $this->db->count_all_results('tb_validasi');

        $this->db->where('status', 'belum ada akun');
        $data['total_belum_ada_akun'] = $this->db->count_all_results('tb_validasi');

        // Simpan data offset untuk dikirim ke view
        $data['offset'] = $offset;

        // Load view dengan data yang sudah diproses
        $this->load->view('admin/v_header');
        $this->load->view('admin/v_validasi', $data);
    }







public function batal_validasi($id_validasi, $id_registrasi) {
    // Hapus data validasi
    $this->M_data->hapus_data('tb_validasi', array('id_validasi' => $id_validasi));

    // Ubah status registrasi menjadi invalid
    $this->M_data->ubah_status_registrasi($id_registrasi, 'invalid');

    // Redirect atau kirim response
    echo json_encode(array('success' => true));
}



// Controller Admin.php
public function registrasi() {
    $this->load->library('pagination');
    $this->load->library('form_validation');

    // Konfigurasi pagination
    $config['base_url'] = base_url('admin/registrasi'); // URL halaman
    $config['total_rows'] = $this->m_data->hitung_data('tb_registrasi'); // Jumlah total data
    $config['per_page'] = 5; // Jumlah data per halaman
    $config['uri_segment'] = 3; // Segment URI untuk nomor halaman

    // Kustomisasi tautan halaman
    $config['attributes'] = array('class' => 'page-link');
    $config['full_tag_open'] = '<nav aria-label="Page navigation example"><ul class="pagination justify-content-center">';
    $config['full_tag_close'] = '</ul></nav>';
    $config['first_link'] = 'First';
    $config['last_link'] = 'Last';
    $config['first_tag_open'] = '<li class="page-item">';
    $config['first_tag_close'] = '</li>';
    $config['prev_link'] = '&laquo';
    $config['prev_tag_open'] = '<li class="page-item">';
    $config['prev_tag_close'] = '</li>';
    $config['next_link'] = '&raquo';
    $config['next_tag_open'] = '<li class="page-item">';
    $config['next_tag_close'] = '</li>';
    $config['last_tag_open'] = '<li class="page-item">';
    $config['last_tag_close'] = '</li>';
    $config['cur_tag_open'] = '<li class="page-item active"><a href="#" class="page-link">';
    $config['cur_tag_close'] = '</a></li>';
    $config['num_tag_open'] = '<li class="page-item">';
    $config['num_tag_close'] = '</li>';

    // Inisialisasi library pagination
    $this->pagination->initialize($config);

    // Ambil data sesuai dengan segment URI
    $offset = $this->uri->segment(3, 0);

    // Ambil kata kunci pencarian dari form
    $search = $this->input->get('search');

    // Ambil tanggal dari form
    $tanggal = $this->input->get('tanggal');

    // Ambil kata kunci pengurutan
    $sort_by = $this->input->get('sort_by');
    $sort_order = $this->input->get('sort_order');

    // Set default jika tidak ada pengurutan
    if (empty($sort_by)) {
        $sort_by = 'tgl_registrasi';
        $sort_order = 'desc';
    }

    // Ambil status validasi dari form
    $status = $this->input->get('status');

    // Jika ada kata kunci pencarian, lakukan pencarian
    if (!empty($search)) {
        $data['peserta'] = $this->m_data->cari_data('tb_registrasi', $search, $config['per_page'], $offset, $sort_by, $sort_order)->result();
        $config['total_rows'] = $this->m_data->hitung_data_cari('tb_registrasi', $search);
    } elseif (!empty($tanggal)) {
        // Jika ada tanggal yang dipilih, lakukan pencarian berdasarkan tanggal
        $data['peserta'] = $this->m_data->cari_data_tanggal('tb_registrasi', $tanggal, $config['per_page'], $offset, $sort_by, $sort_order)->result();
        $config['total_rows'] = $this->m_data->hitung_data_cari_tanggal('tb_registrasi', $tanggal);
    } elseif (!empty($status)) {
        // Jika ada status yang dipilih, lakukan pencarian berdasarkan status validasi
        $data['peserta'] = $this->m_data->ambil_data_status('tb_registrasi', $status, $config['per_page'], $offset, $sort_by, $sort_order)->result();
        $config['total_rows'] = $this->m_data->hitung_data_status('tb_registrasi', $status);
    } else {
        // Jika tidak ada kata kunci pencarian, ambil semua data
        $data['peserta'] = $this->m_data->ambil_data_pagination('tb_registrasi', $config['per_page'], $offset, $sort_by, $sort_order)->result();
    }

    // Update konfigurasi pagination dengan total rows setelah pencarian
    $this->pagination->initialize($config);

    // Hitung total data valid dan invalid
    $data['total_valid'] = $this->m_data->hitung_data_status('tb_registrasi', 'valid');
    $data['total_invalid'] = $this->m_data->hitung_data_status('tb_registrasi', 'invalid');

    // Simpan data pengurutan untuk dikirim ke view
    $data['sort_by'] = $sort_by;
    $data['sort_order'] = $sort_order;
    $data['offset'] = $offset;
    $this->load->view('admin/v_header');
    $this->load->view('admin/v_registrasi', $data);
}

public function validasi($id_registrasi) {
    // Ambil data registrasi berdasarkan $id_registrasi
    $registrasi = $this->db->get_where('tb_registrasi', array('id_registrasi' => $id_registrasi))->row();

    // Jika data registrasi ditemukan, tambahkan ke tabel validasi
    if ($registrasi) {
        $data_validasi = array(
            'id_registrasi' => $registrasi->id_registrasi,
            'nama' => $registrasi->nama_gelar,
            'email' => $registrasi->email,
            'no_wa' => $registrasi->no_wa,
            'tgl_validasi' => date('Y-m-d'),
            'status' => 'belum ada akun' // Atur status sesuai kebutuhan
        );

        // Masukkan data ke tabel validasi
        $this->db->insert('tb_validasi', $data_validasi);

        // Update status registrasi menjadi 'valid' di tb_registrasi
        $this->db->where('id_registrasi', $id_registrasi);
        $this->db->update('tb_registrasi', array('status' => 'valid'));

        // Jika berhasil, arahkan kembali ke halaman registrasi
        redirect('admin/registrasi');
    } else {
        // Jika data registrasi tidak ditemukan, berikan pesan error atau redirect ke halaman lain
        redirect('admin/registrasi');
    }
}
 public function buat_akun($id_validasi) {
    // Ambil data validasi berdasarkan $id_validasi
    $validasi = $this->db->get_where('tb_validasi', array('id_validasi' => $id_validasi))->row();

    // Jika data validasi ditemukan, masukkan ke tabel tb_user
    if ($validasi) {
        $data_user = array(
            'nama' => $validasi->nama,
            'email' => $validasi->email,
            'password' => md5($validasi->email), // Password diambil dari email dan dienkripsi dengan md5
            'status_absen' => 'belum hadir',
            'level' => 'peserta'
        );

        // Masukkan data ke tabel tb_user
        $this->db->insert('tb_user', $data_user);

        // Update status validasi menjadi 'sudah ada akun' di tb_validasi
        $this->db->where('id_validasi', $id_validasi);
        $this->db->update('tb_validasi', array('status' => 'sudah ada akun'));

        echo json_encode(array('success' => true, 'message' => 'Akun berhasil dibuat.'));
    } else {
        echo json_encode(array('success' => false, 'message' => 'Data validasi tidak ditemukan.'));
    }
}


public function pengumuman() {
    $config = array();
    $config["base_url"] = base_url() . "admin/pengumuman";
    $config["total_rows"] = $this->m_data->record_count('tb_pengumuman');
    $config["per_page"] = 5;
    $config["uri_segment"] = 3;
    error_reporting(0);
    // Bootstrap pagination class for styling
    $config['full_tag_open'] = '<ul class="pagination justify-content-center">';
    $config['full_tag_close'] = '</ul>';
    $config['attributes'] = ['class' => 'page-link'];
    $config['first_link'] = 'First';
    $config['last_link'] = 'Last';
    $config['first_tag_open'] = '<li class="page-item">';
    $config['first_tag_close'] = '</li>';
    $config['prev_link'] = '&laquo';
    $config['prev_tag_open'] = '<li class="page-item">';
    $config['prev_tag_close'] = '</li>';
    $config['next_link'] = '&raquo';
    $config['next_tag_open'] = '<li class="page-item">';
    $config['next_tag_close'] = '</li>';
    $config['last_tag_open'] = '<li class="page-item">';
    $config['last_tag_close'] = '</li>';
    $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
    $config['cur_tag_close'] = '</a></li>';
    $config['num_tag_open'] = '<li class="page-item">';
    $config['num_tag_close'] = '</li>';

    $this->pagination->initialize($config);

    $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
    $data["umum"] = $this->m_data->fetch_data('tb_pengumuman', $config["per_page"], $page);
    $data["links"] = $this->pagination->create_links();

    $this->load->view('admin/v_header');
    $this->load->view('admin/v_pengumuman', $data);
}



 public function simpan_pengumuman() {
    // Konfigurasi upload gambar
    $config['upload_path']   = './path_pg/'; // Folder tempat menyimpan gambar
    $config['allowed_types'] = 'jpg|jpeg|png|gif'; // Jenis file yang diizinkan
    $config['max_size']      = 2048; // Ukuran maksimal gambar (dalam KB)

    $this->upload->initialize($config);

    // Ambil data judul, isi, dan link dari form
    $judul = $this->input->post('judul');
    $isi = $this->input->post('isi');
    $link = $this->input->post('link');

    $data = array(
        'judul' => $judul,
        'isi' => $isi,
        'link' => $link,
        'tgl_upload' => date('Y-m-d H:i:s') // Tanggal upload saat ini
    );

    // Cek apakah ada file gambar yang diupload
    if (!empty($_FILES['gambar']['name'])) {
        // Jika upload gagal, tampilkan pesan error
        if (!$this->upload->do_upload('gambar')) {
            $error = $this->upload->display_errors();
            $this->session->set_flashdata('error', $error);
            redirect('admin/pengumuman');
            return; // Hentikan eksekusi jika terjadi error upload
        } else {
            // Jika upload berhasil, ambil data file yang diupload
            $upload_data = $this->upload->data();
            $data['gambar'] = $upload_data['file_name'];
        }
    }

    // Panggil model untuk menyimpan data
    if ($this->m_data->insert_data('tb_pengumuman', $data)) {
        $this->session->set_flashdata('success', 'Pengumuman berhasil ditambahkan.');
    } else {
        $this->session->set_flashdata('error', 'Gagal menyimpan pengumuman.');
    }

    redirect('admin/pengumuman');
}


public function update_pengumuman() {
    $this->load->model('m_data');

    // Ambil ID pengumuman dari input POST
    $id = $this->input->post('id');

    // Ambil judul dan isi pengumuman dari input POST
    $data = [
        'judul' => $this->input->post('judul'),
        'isi' => $this->input->post('isi'),
        'link' => $this->input->post('link')
    ];

    // Cek apakah ada file gambar yang diunggah
    if (!empty($_FILES['gambar']['name'])) {
        // Konfigurasi untuk upload gambar
        $config['upload_path'] = './path_pg/'; // Pastikan path ini benar
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['max_size'] = 2048;
        $config['file_name'] = time() . $_FILES['gambar']['name'];

        // Load library upload dengan konfigurasi yang telah diset
        $this->load->library('upload', $config);

        // Lakukan proses upload
        if ($this->upload->do_upload('gambar')) {
            // Ambil nama file gambar yang lama
            $old_image = $this->m_data->get_image_name($id);
            
            // Jika ada gambar lama, hapus gambar tersebut
            if ($old_image) {
                $image_path = './path_pg/' . $old_image;
                if (file_exists($image_path)) {
                    unlink($image_path);
                }
            }

            // Ambil data upload gambar yang baru
            $uploadData = $this->upload->data();
            $data['gambar'] = $uploadData['file_name'];
        } else {
            // Jika proses upload gagal, tampilkan error
            $this->session->set_flashdata('error', $this->upload->display_errors());
            redirect('admin/pengumuman');
        }
    }

    // Update data pengumuman ke database
    $this->m_data->update_data(['id_pengumuman' => $id], $data, 'tb_pengumuman');

    // Set flashdata untuk notifikasi sukses
    $this->session->set_flashdata('success', 'Pengumuman berhasil diupdate.');

    // Redirect kembali ke halaman pengumuman
    redirect('admin/pengumuman');
}





public function hapus_pengumuman($id) {
    $this->load->model('m_data');
    
    // Make sure the table name is correctly specified
    $this->m_data->hapus_data1(['id_pengumuman' => $id], 'tb_pengumuman');
    
    $this->session->set_flashdata('success', 'Pengumuman berhasil dihapus.');
    redirect('admin/pengumuman');
}






public function akun() {
    $this->load->model('m_data');
    
    // Load library pagination
    $this->load->library('pagination');

    // Konfigurasi pagination
    $config = [
        'base_url' => base_url('admin/akun'),
        'total_rows' => $this->m_data->ambil_data('tb_user')->num_rows(),
        'per_page' => 5,
    ];

    $config['uri_segment'] = 3;
    $config['use_page_numbers'] = TRUE;
    $config['attributes'] = array('class' => 'page-link');

    // Inisialisasi library pagination
    $this->pagination->initialize($config);

    // Ambil data akun untuk halaman saat ini
    $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
    $data['akun'] = $this->m_data->ambil_data('tb_user', $config['per_page'], $page)->result();
    
    $search = $this->input->get('search');

    // Query untuk mengambil data akun dengan filter nama atau email
    $this->db->select('*');
    $this->db->from('tb_user');

    if (!empty($search)) {
        // Filter berdasarkan nama atau email
        $this->db->like('nama', $search);
        $this->db->or_like('email', $search);
    }

    $query = $this->db->get();
    $data['akun'] = $query->result();
    // Buat link pagination
    $data['pagination'] = $this->pagination->create_links();

    // Load view dengan data akun dan pagination
    $this->load->view('admin/v_header');
    $this->load->view('admin/v_akun', $data);
}

public function hapus_akun($id)
{
    $this->load->model('m_data');
    $result = $this->m_data->hapus_data('tb_user', array('id_user' => $id));
    if ($result) {
        echo json_encode(array('success' => true));
    } else {
        echo json_encode(array('success' => false));
    }
}


 // Controller Admin.php
public function update_akun() {
    $id = $this->input->post('id');
    $email = $this->input->post('email');
    $password = $this->input->post('password');

    // Enkripsi password menggunakan MD5
    $hashed_password = md5($password);

    // Contoh update data ke dalam database
    $update_data = array(
        'email' => $email,
        'password' => $hashed_password
    );

    $this->db->where('id_user', $id);
    $this->db->update('tb_user', $update_data);

    if ($this->db->affected_rows() > 0) {
        $response['success'] = true;
    } else {
        $response['success'] = false;
    }

    echo json_encode($response);
}



// Controller Admin.php
// Controller Admin.php
public function absensi() {
    $this->load->model('m_data');
    $this->load->library('pagination');

    // Ambil input pencarian dari form
    $search_nama_email = $this->input->get('search');
    $search_status_absen = $this->input->get('status_absen');

    // Konfigurasi pagination
    $config['base_url'] = base_url('admin/absensi');
    $config['total_rows'] = $this->m_data->count_all('tb_user', $search_nama_email, $search_status_absen); // Jumlah total data dengan pencarian
    $config['per_page'] = 5; // Jumlah data per halaman
    $config['uri_segment'] = 3; // Segment URI yang digunakan untuk nomor halaman
    $this->pagination->initialize($config);

    // Ambil data dengan pagination dan pencarian
    $start = $this->uri->segment(3, 0); // Ambil nomor halaman dari URI
    $data['akun'] = $this->m_data->ambil_data_paginasi('tb_user', $config['per_page'], $start, $search_nama_email, $search_status_absen)->result();

    // Hitung total data yang hadir dan yang tidak hadir
    $data['total_hadir'] = $this->m_data->count_by_status_absen('tb_user', 'Hadir', $search_nama_email);
    $data['total_tidak_hadir'] = $this->m_data->count_by_status_absen('tb_user', 'Belum Hadir', $search_nama_email);

    // Mengirim data ke view
    $data['config'] = $config; // Mengirim konfigurasi pagination ke view

    // Load view dengan data akun
    $this->load->view('admin/v_header');
    $this->load->view('admin/v_absensi', $data);
}



}
