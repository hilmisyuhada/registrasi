<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Peserta extends CI_Controller {
		public function __construct() {
        parent::__construct();
        check_login();
        $this->load->model('M_data');
        $this->load->library('session');
        $this->load->library('form_validation');
        
    }
	public function index() {
$this->load->library('pagination');
     $config = array();
        $config["base_url"] = base_url() . "peserta/index";
        $config["total_rows"] = $this->m_data->record_count('tb_pengumuman');
        $config["per_page"] = 5;
        $config["uri_segment"] = 3;
        error_reporting(0);
        // Bootstrap pagination class for styling
        $config['full_tag_open'] = '<ul class="pagination justify-content-center">';
        $config['full_tag_close'] = '</ul>';
        $config['attributes'] = ['class' => 'page-link'];
        $config['first_link'] = 'First';
        $config['last_link'] = 'Last';
        $config['first_tag_open'] = '<li class="page-item">';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = '&laquo';
        $config['prev_tag_open'] = '<li class="page-item">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = '&raquo';
        $config['next_tag_open'] = '<li class="page-item">';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li class="page-item">';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li class="page-item">';
        $config['num_tag_close'] = '</li>';

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data["umum"] = $this->m_data->fetch_data('tb_pengumuman', $config["per_page"], $page);
        $data["links"] = $this->pagination->create_links();

        $this->load->view('peserta/v_header');
        $this->load->view('peserta/v_index', $data);
       
    }
	public function profil() {
    $this->load->model('m_data');
    $user_id = $this->session->userdata('id_user'); // Asumsi Anda menyimpan ID pengguna di session
    $data['user'] = $this->m_data->get_user_by_id($user_id);

    $this->load->view('peserta/v_header');
    $this->load->view('peserta/v_profil', $data);
}

// Metode untuk memperbarui profil
public function update_profil() {
    $this->load->model('m_data');
    $user_id = $this->session->userdata('id_user');
    $data = [
        'nama' => $this->input->post('nama'),
        'email' => $this->input->post('email'),
    ];

    // Hanya memperbarui password jika ada input password baru
    if ($this->input->post('password')) {
        $data['password'] = md5($this->input->post('password'));
    }

    $this->m_data->update_user($user_id, $data);
    $this->session->set_flashdata('success', 'Profil berhasil diperbarui.');
    redirect('peserta/profil');
}


}
