<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_data extends CI_Model {

	public function cek_login($email, $password)
    {
        $this->db->where('email', $email);
        $this->db->where('password', md5($password)); 
        $query = $this->db->get('tb_user');

        if($query->num_rows() > 0) {
            return $query->row_array();
        } else {
            return false; 
        }
    }
    public function tambah_data($data, $table) {
        // Insert data into database
        $this->db->insert($table, $data);
        return $this->db->affected_rows() > 0;
    }
 public function get_by_columns($table, $columns) {
    // Check if data exists by matching any of the columns
    $this->db->select('*')->from($table);
    $this->db->group_start();
    foreach ($columns as $key => $value) {
        $this->db->or_where($key, $value);
    }
    $this->db->group_end();
    $query = $this->db->get();
    return $query->row_array(); // Assuming we expect only one row, adjust if needed
}

// Model m_data.php
public function count_by_status_absen($table, $status_absen, $search_nama_email = null) {
    $this->db->from($table);
    $this->db->where('status_absen', $status_absen);

    // Filter berdasarkan nama atau email
    if ($search_nama_email) {
        $this->db->group_start();
        $this->db->like('nama', $search_nama_email);
        $this->db->or_like('email', $search_nama_email);
        $this->db->group_end();
    }

    return $this->db->count_all_results();
}


public function ambil_data_pagination($table, $limit, $offset) {
    return $this->db->get($table, $limit, $offset);
}

public function hitung_data($table) {
    return $this->db->count_all($table);
}
// Model M_data.php
public function hitung_data_status($table, $status) {
    $this->db->where('status', $status);
    return $this->db->get($table)->num_rows();
}

public function cari_data_tanggal($table, $tanggal, $limit, $offset, $sort_by = 'tgl_registrasi', $sort_order = 'desc') {
    $this->db->where('tgl_registrasi', $tanggal);
    $this->db->order_by($sort_by, $sort_order);
    $this->db->limit($limit, $offset);
    return $this->db->get($table);
}

public function hitung_data_cari_tanggal($table, $tanggal) {
    $this->db->where('tgl_registrasi', $tanggal);
    return $this->db->count_all_results($table);
}

public function cari_data($table, $keyword, $limit, $offset) {
    $this->db->like('nama_gelar', $keyword); // Sesuaikan dengan kolom yang ingin dicari
    $this->db->or_like('no_wa', $keyword); // Kolom lain yang ingin dicari
    $this->db->limit($limit, $offset);
    return $this->db->get($table);
}

public function hitung_data_cari($table, $keyword) {
    $this->db->like('nama_gelar', $keyword); // Sesuaikan dengan kolom yang ingin dicari
    $this->db->or_like('no_wa', $keyword); // Kolom lain yang ingin dicari
    return $this->db->count_all_results($table);
}
public function hapus_data($table, $where) {
    $this->db->where($where);
    $this->db->delete($table);
    return $this->db->affected_rows() > 0;
}
public function hapus_data1($where, $table) {
    // Example of using CodeIgniter's Query Builder for deletion
    $this->db->delete($table, $where);
}
public function input_data($data, $table) {
    $this->db->insert($table, $data);
}


public function get_user_by_id($id) {
        return $this->db->get_where('tb_user', ['id_user' => $id])->row();
    }

    public function update_user($id, $data) {
        $this->db->where('id_user', $id);
        return $this->db->update('tb_user', $data);
    }
 public function count_all1() {
        return $this->db->count_all('tb_registrasi');
    }
    public function fetch_data1($limit, $start, $query = NULL) {
        if ($query) {
            $this->db->like('nama_gelar', $query);
        }
        $this->db->limit($limit, $start);
        $query = $this->db->get('tb_registrasi');

        if ($query->num_rows() > 0) {
            return $query->result();
        }
        return false;
    }


public function ubah_status_registrasi($id_registrasi, $status) {
    $this->db->where('id_registrasi', $id_registrasi);
    $this->db->update('tb_registrasi', array('status' => $status));
    return $this->db->affected_rows() > 0;
}
public function cari_data_validasi($table, $keyword, $tanggal, $limit, $offset) {
    $this->db->from($table);

    if (!empty($keyword)) {
        $this->db->group_start();
        $this->db->like('nama', $keyword);
        $this->db->or_like('no_wa', $keyword);
        $this->db->group_end();
    }

    if (!empty($tanggal)) {
        $this->db->where('tgl_validasi', $tanggal);
    }

    $this->db->limit($limit, $offset);
    return $this->db->get();
}

public function tambah_akun($data_user) {
        // Insert data into tb_user
        $this->db->insert('tb_user', $data_user);
        return $this->db->affected_rows() > 0;
    }

    public function update_status_validasi($id_validasi, $status) {
        $this->db->where('id_validasi', $id_validasi);
        $this->db->update('tb_validasi', array('status' => $status));
        return $this->db->affected_rows() > 0;
    }

public function hitung_data_validasi($table, $keyword, $tanggal) {
    $this->db->from($table);

    if (!empty($keyword)) {
        $this->db->group_start();
        $this->db->like('nama', $keyword);
        $this->db->or_like('no_wa', $keyword);
        $this->db->group_end();
    }

    if (!empty($tanggal)) {
        $this->db->where('tgl_validasi', $tanggal);
    }

    return $this->db->count_all_results();
}

// Model M_data.php
public function ambil_data_status($table, $status, $limit, $offset, $sort_by, $sort_order) {
    $this->db->where('status', $status);
    $this->db->order_by($sort_by, $sort_order);
    return $this->db->get($table, $limit, $offset);
}

 // Model m_data.php
public function ambil_data_paginasi($table, $limit, $start, $search_nama_email = null, $search_status_absen = null) {
    $this->db->from($table);

    // Filter berdasarkan nama atau email
    if ($search_nama_email) {
        $this->db->group_start();
        $this->db->like('nama', $search_nama_email);
        $this->db->or_like('email', $search_nama_email);
        $this->db->group_end();
    }

    // Filter berdasarkan status_absen
    if ($search_status_absen) {
        $this->db->where('status_absen', $search_status_absen);
    }

    $this->db->limit($limit, $start);
    return $this->db->get();
}

public function count_all($table, $search_nama_email = null, $search_status_absen = null) {
    // Menghitung total rows dengan filter pencarian
    $this->db->from($table);

    // Filter berdasarkan nama atau email
    if ($search_nama_email) {
        $this->db->group_start();
        $this->db->like('nama', $search_nama_email);
        $this->db->or_like('email', $search_nama_email);
        $this->db->group_end();
    }

    // Filter berdasarkan status_absen
    if ($search_status_absen) {
        $this->db->where('status_absen', $search_status_absen);
    }

    return $this->db->count_all_results();
}


    public function ambil_data($table, $limit = null, $offset = null) {
    if ($limit && $offset) {
        $this->db->limit($limit, $offset);
    }
    return $this->db->get($table);
}
public function insert_data($table, $data) {
        return $this->db->insert($table, $data);
    }

     public function record_count($table) {
        return $this->db->count_all($table);
    }

    public function fetch_data($table, $limit, $start) {
        $this->db->limit($limit, $start);
        $query = $this->db->get($table);

        if ($query->num_rows() > 0) {
            return $query->result();
        }
        return false;
    }
   
   public function get_image_name($id) {
        $this->db->select('gambar');
        $this->db->where('id_pengumuman', $id);
        $query = $this->db->get('tb_pengumuman');
        $result = $query->row();
        if ($result) {
            return $result->gambar;
        }
        return false;
    }

    // Update data pengumuman berdasarkan kondisi yang diberikan
    public function update_data($where, $data, $table) {
        $this->db->where($where);
        $this->db->update($table, $data);
        return $this->db->affected_rows();
    }


}
