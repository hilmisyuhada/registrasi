<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Daftar Peserta Webinar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link type="text/css" href="<?php echo base_url().'assets/@fortawesome/fontawesome-free/css/all.min.css'?>" rel="stylesheet">
    <style type="text/css">
        .card-registration .select-input.form-control[readonly]:not([disabled]) {
            font-size: 1rem;
            line-height: 2.15;
            padding-left: .75em;
            padding-right: .75em;
        }
        .card-registration .select-arrow {
            top: 13px;
        }
    </style>
</head>
<body>
    <center>
        <h1 class="display-1 mb-5">Daftar Peserta Webinar</h1>
    </center>

    <div class="container d-flex justify-content-center">
        <div class="w-70" style="width: 70%;">
            <form class="d-flex mb-3" role="search" method="get" action="<?php echo site_url('login/index'); ?>">
                <input class="form-control me-2" type="search" name="search" placeholder="Cari Nama Anda" aria-label="Search" value="<?php echo $this->input->get('search'); ?>">
                <button class="btn btn-outline-success" type="submit">Cari!</button>
            </form>
            <table class="table table-dark table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama Peserta</th>
                        <th scope="col">Tanggal Mendaftar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0; ?>
                    <?php if($peserta) { foreach($peserta as $p) { ?>
                    <tr>
                        <td><?php echo ++$no; ?></td> 
                        <td><?php echo $p->nama_gelar; ?></td>
                        <td><?php echo $p->tgl_registrasi; ?></td>
                    </tr>
                    <?php } } else { ?>
                    <tr>
                        <td colspan="3" class="text-center">Data tidak ditemukan</td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
            <?php echo $links; ?>
            <a href="<?php echo base_url().'login/regis'?>" class="link-primary text-decoration-none">Belum terdaftar? Silahkan Klik Disini!</a><br><hr>
            <a href="<?php echo base_url().'login/lgin'?>" class="link-primary text-decoration-none">Sudah Punya Akun? Silahkan Klik Disini!</a>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
</body>
</html>
