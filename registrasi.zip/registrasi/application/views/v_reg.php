<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registrasi Event</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link type="text/css" href="<?php echo base_url().'assets/@fortawesome/fontawesome-free/css/all.min.css'?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.3/dist/sweetalert2.min.css">
    <style type="text/css">
        .card-registration .select-input.form-control[readonly]:not([disabled]) {
            font-size: 1rem;
            line-height: 2.15;
            padding-left: .75em;
            padding-right: .75em;
        }
        .card-registration .select-arrow {
            top: 13px;
        }
        .event-image-container {
            height: 100%; /* Set tinggi sesuai kebutuhan */
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .event-image {
            max-width: 100%; /* Lebar maksimum gambar */
            max-height: 100%; /* Tinggi maksimum gambar */
            object-fit: cover; /* Memastikan gambar tetap proporsional */
        }
    </style>
</head>
<body>
<section class="bg-light p-3 p-md-4 p-xl-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-xxl-11">
                <div class="card border-light-subtle shadow-sm">
                    <div class="row g-0">
                        <div class="col-12 col-md-6">
                            <div class="event-image-container">
                                <img class="img-fluid rounded-start event-image" loading="lazy" src="<?php echo base_url().'assets/Flyer30Juni.jpg'?>" alt="Event Image">
                            </div>
                        </div>
                        <div class="col-12 col-md-6 d-flex align-items-center justify-content-center">
                            <div class="col-12 col-lg-11 col-xl-10">
                                <div class="card-body p-3 p-md-4 p-xl-5">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="mb-3">
                                                <div class="text-center mb-2">
                                                    <a href="#!">
                                                        <img src="<?php echo base_url().'assets/Logo.png'?>" alt="Logo" width="175" height="125">
                                                    </a>
                                                </div>
                                                <h5 class="text-center">Silahkan Registrasi Untuk Mengakses Event <br> ENT Webinar Series Faring Laring 1 <br> 30 Juni 2024</h5>
                                                <hr>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12">
                                            <form id="registrationForm" action="<?php echo base_url('login/daftar') ?>" method="post" enctype="multipart/form-data">
                                                <div class="row gy-3 overflow-hidden">
                                                    <div class="col-12">
                                                        <div class="mb-3">
                                                            <label class="form-label d-block">Saya Mengikuti <b>ENT WEBINAR SERIES FARING LARING-1</b> Tanggal 30 Juni 2024</label>
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="radio" name="pilihan" id="entWebinarYes" value="ya" required>
                                                                <label class="form-check-label" for="entWebinarYes">Ya</label>
                                                            </div>
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="radio" name="pilihan" id="entWebinarNo" value="tidak" required>
                                                                <label class="form-check-label" for="entWebinarNo">Tidak</label>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-12">
                                                        <div class="form-floating mb-3 position-relative">
                                                            <input type="email" class="form-control" name="email" id="email" placeholder=" Contoh(Dr.Fulan, S.Kom)" required>
                                                            <label for="email" class="form-label">Email</label>
                                                            <span class="position-absolute top-50 start-0 translate-middle-y ps-3"><i class="fas fa-envelope"></i></span>
                                                        </div>
                                                    </div>

                                                    <div class="col-12">
                                                        <div class="form-floating mb-3 position-relative">
                                                            <input type="text" class="form-control" name="nama_gelar" id="nama_gelar" placeholder=" Contoh(Dr.Fulan, S.Kom)" required>
                                                            <label for="nama_gelar" class="form-label">Gelar Dan Nama Lengkap</label>
                                                            <span class="position-absolute top-50 start-0 translate-middle-y ps-3"><i class="fas fa-user"></i></span>
                                                        </div>
                                                    </div>

                                                    <div class="col-12">
                                                        <div class="form-floating mb-3 position-relative">
                                                            <input type="text" class="form-control" name="ttl" id="ttl" placeholder="Masukkan Tempat Tanggal Lahir Anda" required>
                                                            <label for="ttl" class="form-label">Tempat Tanggal Lahir</label>
                                                            <span class="position-absolute top-50 start-0 translate-middle-y ps-3"><i class="fas fa-calendar-alt"></i></span>
                                                        </div>
                                                    </div>

                                                    <div class="col-12">
                                                        <div class="form-floating mb-3 position-relative">
                                                            <input type="text" class="form-control" name="profesi" id="profesi" placeholder="Masukkan Profesi Anda" required>
                                                            <label for="profesi" class="form-label">Profesi</label>
                                                            <span class="position-absolute top-50 start-0 translate-middle-y ps-3"><i class="fas fa-briefcase"></i></span>
                                                        </div>
                                                    </div>

                                                    <div class="col-12">
                                                        <div class="form-floating mb-3 position-relative">
                                                            <textarea class="form-control" name="alamat" id="alamat" placeholder="Masukkan Alamat Anda"></textarea>
                                                            <label for="alamat" class="form-label">Alamat</label>
                                                            <span class="position-absolute top-50 start-0 translate-middle-y ps-3"><i class="fas fa-map-marker-alt"></i></span>
                                                        </div>
                                                    </div>

                                                    <div class="col-12">
                                                        <div class="form-floating mb-3 position-relative">
                                                            <input type="number" class="form-control" name="no_wa" id="no_wa" placeholder="Masukkan No Whatsapp Anda" required>
                                                            <label for="no_wa" class="form-label">No Whatsapp</label>
                                                            <span class="position-absolute top-50 start-0 translate-middle-y ps-3"><i class="fas fa-phone"></i></span>
                                                        </div>
                                                    </div>

                                                    <div class="col-12">
                                                        <div class="mb-3">
                                                            <label for="bukti_tf" class="form-label">Upload Bukti Pembayaran</label>
                                                            <input class="form-control" type="file" id="bukti_tf" name="bukti_tf" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="d-grid">
                                                            <button class="btn btn-primary btn-lg" type="submit">Registrasi !</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="d-flex gap-2 gap-md-4 flex-column flex-md-row justify-content-md-center mt-5">
                                                        <a href="<?php echo base_url().'login/lgin'?>" class="link-secondary text-decoration-none">Login</a>
                                                        <a href="#!" class="link-secondary text-decoration-none text-success">Helpdesk!</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.3/dist/sweetalert2.min.js"></script>
<script>
    // Handle form submission with SweetAlert for response
    document.addEventListener('DOMContentLoaded', function () {
        const form = document.getElementById('registrationForm');
        form.addEventListener('submit', function (event) {
            event.preventDefault(); // Prevent default form submission

            // Prepare form data to submit via Ajax
            const formData = new FormData(form);

            // Perform Ajax POST request
            fetch(form.action, {
                method: form.method,
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                // Check response status
                if (data.status === 'success') {
                    // Registration successful
                    Swal.fire({
                        icon: 'success',
                        title: 'Registrasi Berhasil!',
                        text: 'Data Anda berhasil terinput. Tunggu sampai data anda tervalidasi dan akan segera dikirimkan data akun anda',
                        confirmButtonText: 'OK'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.href = '<?php echo base_url()."login/lgin"; ?>'; // Redirect to login page
                        }
                    });
                } else if (data.status === 'error') {
                    // Handle specific error case (duplicate entry)
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: data.message || 'Terjadi kesalahan. Silakan coba lagi.'
                    });
                } else {
                    // Handle generic error case
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: 'Terjadi kesalahan. Silakan coba lagi. Jika masih bermasalah, silahkan hubungi helpdesk!'
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                // Show generic error message
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Terjadi kesalahan. Silakan coba lagi. Jika masih bermasalah, silahkan hubungi helpdesk!'
                });
            });
        });
    });
</script>

</body>
</html>
