<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ENT Webinar Series</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link type="text/css" href="<?php echo base_url().'assets/@fortawesome/fontawesome-free/css/all.min.css'?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .navbar {
            background-color: #f8f9fa; /* Light grey background */
        }
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
            color: #007bff !important;
        }
        .nav-link {
            font-size: 1.1rem;
            margin-right: 15px;
            transition: color 0.3s ease;
        }
        .nav-link:hover {
            color: #0056b3 !important;
        }
        .navbar-toggler-icon {
            color: #007bff;
        }
        .dropdown-menu {
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .dropdown-item:hover {
            background-color: #007bff;
            color: #ffffff !important;
        }
        .no-select {
            user-select: none; /* Disable text selection */
            -webkit-user-select: none; /* Safari */
            -moz-user-select: none; /* Firefox */
            -ms-user-select: none; /* Internet Explorer/Edge */
        }
    </style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
      <div class="container-fluid">
        <a class="navbar-brand" href="#"><i class="fas fa-video"></i> ENT Webinar Series</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link active text-primary" aria-current="page" href="<?php echo base_url().'peserta/index'?>"><i class="fas fa-home"></i> Beranda</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url().'peserta/profil'?>"><i class="fas fa-user"></i> Profil</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-info-circle"></i> Panduan Penggunaan
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#"><i class="fas fa-chalkboard-teacher"></i> Akses Pelataran Sehat</a></li>
                <li><a class="dropdown-item" href="#"><i class="fas fa-video"></i> Akses Zoom</a></li>
                <li><a class="dropdown-item" href="#"><i class="fas fa-book"></i> Akses Pembelajaran Materi</a></li>
              </ul>
            </li>
            <li class="nav-item">
              <a class="nav-link text-danger" href="<?php echo base_url().'login/logout'?>"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
  </body>
</html>
