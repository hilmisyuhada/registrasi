<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .highlight {
            background-color: #6c757d;
            color: white;
            border-radius: 10px;
            padding: 5px 10px;
        }
        .card {
            border: none;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2); /* Thicker shadow */
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.2); /* Even thicker shadow on hover */
        }
        .no-select {
            user-select: none;
        }
        .announcement-title {
            color: #007bff;
        }
    </style>
    <title>Sistem Informasi ENT Webinar Series</title>
</head>
<body>

<div class="container mt-5 mb-5">
    <hr>
    <center>
        <h1 class="display-5 mb-3">Selamat datang di aplikasi Sistem Informasi ENT Webinar Series</h1>
        <p class="display-6 mb-3">
            Halo <b><span class="highlight"><?php echo $this->session->userdata('nama'); ?></span></b>, Anda Login sebagai <b><span class="text-primary">Peserta</span></b>
        </p>
    </center>
    <hr>

    <center>
        <h1 class="display-1 mb-5 announcement-title">Pengumuman</h1>
    </center>

    <div class="row">
        <?php foreach ($umum as $pengumuman) : ?>
            <div class="col-md-6">
                <div class="card mb-3" style="max-width: 540px;">
                    <div class="row g-0">
                        <?php if (!empty($pengumuman->gambar)) : ?>
                            <div class="col-md-4">
                                <img src="<?php echo base_url('./path_pg/') . $pengumuman->gambar; ?>" class="img-fluid rounded-start" alt="...">
                            </div>
                        <?php endif; ?>
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title no-select"><?php echo $pengumuman->judul; ?></h5>
                                <p class="card-text no-select"><?php echo $pengumuman->isi; ?></p>
                                <?php if (!empty($pengumuman->link)) : ?>
                                    <p class="card-text"><a href="<?php echo $pengumuman->link; ?>">Klik Disini</a></p>
                                <?php endif; ?>
                                <p class="card-text"><small class="text-muted">Last updated <?php echo date('d M Y', strtotime($pengumuman->tgl_upload)); ?></small></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <div class="row">
        <div class="col-md-12 text-center">
            <?php echo $links; ?>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.min.js"></script>
</body>
</html>
