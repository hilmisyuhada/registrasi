
<body>
    <div class="container mt-5 mb-5">
        <hr>
        <center>
            <h1 class="display-3 mb-5">Pengumuman</h1>
        </center>
        <hr>

        <!-- Tampilkan pesan flashdata -->
        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert alert-success">
                <?php echo $this->session->flashdata('success'); ?>
            </div>
        <?php endif; ?>
        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-danger">
                <?php echo $this->session->flashdata('error'); ?>
            </div>
        <?php endif; ?>

        <!-- Form tambah pengumuman -->
        <div id="formTambahPengumuman" class="card p-4 mb-5">
            <form action="<?php echo base_url('admin/simpan_pengumuman'); ?>" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="judul">Judul</label>
                    <input type="text" class="form-control" id="judul" name="judul" required>
                </div>
                <div class="form-group">
                    <label for="isi">Isi Pengumuman</label>
                    <textarea class="form-control" id="isi" name="isi" rows="3" required></textarea>
                </div>
                <div class="form-group">
                    <label for="link">Link</label>
                    <input type="text" class="form-control" id="link" placeholder="kosongkan jika tidak perlu" name="link">
                </div>
                <div class="form-group">
                    <label for="gambar">Gambar</label>
                    <input type="text" class="form-control" id="gambar_text" readonly placeholder="Pilih gambar...">
                    <input type="file" class="form-control-file mt-2" id="gambar" name="gambar">
                </div>
                <button type="submit" class="btn mt-3 btn-primary">Sebar</button>
            </form>
        </div>

        <!-- Daftar pengumuman -->
        <div class="row">
            <?php foreach ($umum as $pengumuman) : ?>
                <div class="col-md-6">
                    <div class="card mb-3" style="max-width: 540px;">
                        <div class="row no-gutters">
                            <div class="col-md-4">
                                 <?php if (!empty($pengumuman->gambar)) : ?>

                                <img src="<?php echo base_url('./path_pg/') . $pengumuman->gambar; ?>" class="img-fluid rounded-start" alt="...">
                                 <?php endif; ?>
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h5 class="card-title no-select"><?php echo $pengumuman->judul; ?></h5>
                                    <p class="card-text no-select"><?php echo $pengumuman->isi; ?></p>
                                    <?php if (!empty($pengumuman->link)) : ?>
                                        <p class="card-text"><a href="<?php echo $pengumuman->link; ?>">Klik Disini</a></p>
                                    <?php endif; ?>
                                    <p class="card-text"><small class="text-muted">Last updated <?php echo date('d M Y', strtotime($pengumuman->tgl_upload)); ?></small></p>
                                    <!-- Tombol Edit -->
                                    <button class="btn btn-warning btn-sm" onclick="editPengumuman(<?php echo $pengumuman->id_pengumuman; ?>, '<?php echo $pengumuman->judul; ?>', '<?php echo $pengumuman->isi; ?>', '<?php echo $pengumuman->link; ?>', '<?php echo $pengumuman->gambar; ?>')">Edit</button>
                                    <!-- Tombol Hapus -->
                                    <button class="btn btn-danger btn-sm" onclick="hapusPengumuman(<?php echo $pengumuman->id_pengumuman; ?>)">Hapus</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Pagination Links -->
        <div class="row">
            <div class="col-md-12 text-center">
                <?php echo $links; ?>
            </div>
        </div>
    </div>

    <!-- JavaScript untuk menangani file input dan penghapusan pengumuman -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Update gambar preview saat memilih gambar baru pada form tambah
        document.querySelector('#gambar').addEventListener('change', function(e) {
            var fileName = this.files[0].name;
            document.getElementById('gambar_text').value = fileName;
        });

        // Memunculkan konfirmasi penghapusan pengumuman
        function hapusPengumuman(id) {
            Swal.fire({
                title: 'Anda yakin?',
                text: "Pengumuman ini akan dihapus!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, hapus!'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Mengirimkan permintaan penghapusan ke server
                    $.ajax({
                        url: '<?php echo base_url('admin/hapus_pengumuman/'); ?>' + id,
                        type: 'GET',
                        success: function(response) {
                            // Tampilkan pesan sukses jika penghapusan berhasil
                            Swal.fire(
                                'Terhapus!',
                                'Pengumuman berhasil dihapus.',
                                'success'
                            ).then((result) => {
                                // Muat ulang halaman setelah menutup alert
                                location.reload();
                            });
                        },
                        error: function(xhr, status, error) {
                            // Tampilkan pesan error jika penghapusan gagal
                            Swal.fire(
                                'Gagal!',
                                'Gagal menghapus pengumuman.',
                                'error'
                            );
                        }
                    });
                }
            });
        }

        // Fungsi JavaScript untuk mengisi form edit
        function editPengumuman(id, judul, isi, link, gambar) {
            // Mengisi nilai form edit dengan data pengumuman yang akan di-edit
            document.getElementById('formTambahPengumuman').innerHTML = `
                <form action="<?php echo base_url('admin/update_pengumuman'); ?>" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="${id}">
                    <div class="form-group">
                        <label for="judul">Judul</label>
                        <input type="text" class="form-control" id="judul" name="judul" value="${judul}" required>
                    </div>
                    <div class="form-group">
                        <label for="isi">Isi Pengumuman</label>
                        <textarea class="form-control" id="isi" name="isi" rows="3" required>${isi}</textarea>
                    </div>
                    <div class="form-group">
                        <label for="link">Link</label>
                        <input type="text" class="form-control" id="link" placeholder="kosongkan bila tidak perlu" name="link" value="${link}">
                    </div>
                    <button type="submit" class="btn mt-3 btn-primary">Update</button>
                </form>
            `;

            // Set nilai nama file gambar pada input text
            document.getElementById('gambar_text').value = gambar;
        }
    </script>
</body>
</html>
