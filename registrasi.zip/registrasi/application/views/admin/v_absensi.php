<!-- application/views/admin/v_absensi.php -->

<div class="container mt-5 mb-5">
    <hr>
    <center>
        <p class="display-6 mb-3">Data Akun Pendaftar Webinar Yang Telah Tervalidasi</p>
        <p class=" my-3">Total Akun <?php echo $this->M_data->count_all('tb_user', $this->input->get('search'), $this->input->get('status_absen')); ?></p>
        <p class=" my-3">Total Hadir: <?php echo $total_hadir; ?></p>
        <p class=" my-3">Total Tidak Hadir: <?php echo $total_tidak_hadir; ?></p>
        <marquee>
            <p class="mb-3">Acara yang berlangsung ENT Webinar Series Faring Laring-1</p>
        </marquee>
    </center>
    <hr>
</div>

<!-- Main Content -->
<div class="container">
    <!-- Search Bar -->
    <nav class="navbar bg-light mb-4">
        <div class="container-fluid">
            <form class="d-flex" role="search" method="get" action="<?php echo base_url('admin/absensi'); ?>">
                <input class="form-control me-2" type="search" placeholder="Cari Data Nama/Email" aria-label="Search by Name/Email" name="search" value="<?php echo htmlentities($this->input->get('search')); ?>">
                <select class="form-select me-2" name="status_absen">
                    <option value="">Pilih Status Absen</option>
                    <option value="Hadir" <?php echo ($this->input->get('status_absen') == 'Hadir') ? 'selected' : ''; ?>>Hadir</option>
                    <option value="Tidak Hadir" <?php echo ($this->input->get('status_absen') == 'Tidak Hadir') ? 'selected' : ''; ?>>Tidak Hadir</option>
                </select>
                <button class="btn btn-outline-success" type="submit">Cari!</button>
            </form>
        </div>
    </nav>

    <!-- Table Section -->
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>No</th>
                   
                    <th>Nama</th>
                    <th>Status</th>
                    <th>Email</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = $this->uri->segment(3, 0) + 1; foreach($akun as $p) { ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    
                    <td><?php echo $p->nama; ?></td>
                    <td><?php echo $p->status_absen; ?></td>
                    <td><?php echo $p->email; ?></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination Links -->
    <?php if(isset($config) && $config['total_rows'] > $config['per_page']) { ?>
    <nav aria-label="Page navigation example">
        <ul class="pagination">
            <?php echo $this->pagination->create_links(); ?>
        </ul>
    </nav>
    <?php } ?>
</div>
