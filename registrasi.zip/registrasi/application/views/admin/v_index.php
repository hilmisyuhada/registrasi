<div class="container mt-5 mb-5">
  <hr>
  <center>
    <h1 class="display-4 mb-3">Selamat datang di aplikasi Sistem Informasi ENT Webinar Series</h1>
     <p class="display-6 mb-3"> Halo <?php echo $this->session->userdata('nama'); ?>! Anda Login sebagai <b><span class="text-success">Admin</span></b></p>
      <marquee><p class="mb-3"> Acara yang berlangsung ENT Webinar Series Faring Laring-1 </p></marquee>
 </center>
 <hr>
        
</div>
