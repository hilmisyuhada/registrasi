<div class="container mt-5 mb-5">
    <hr>
    <center>
        <p class="display-6 mb-3">Data Pendaftar Webinar Yang Telah Tervalidasi</p>
        <div class="container mt-3">
             <p class=" my-3">Total Pendaftar <?php echo $this->m_data->ambil_data('tb_registrasi')->num_rows(); ?></p>
            <p>Total Data Sudah Ada Akun: <?php echo $total_sudah_ada_akun; ?></p>
            <p>Total Data Belum Ada Akun: <?php echo $total_belum_ada_akun; ?></p>
        </div>
        <marquee>
            <p class="mb-3">Acara yang berlangsung ENT Webinar Series Faring Laring-1</p>
        </marquee>
    </center>
    <hr>
</div>

<!-- Main Content -->
<div class="container">
    <!-- Search Bar -->
    <nav class="navbar bg-light mb-4">
        <div class="container-fluid">
            <form class="d-flex" role="search" method="get" action="<?php echo base_url('admin/valid'); ?>">
                <input class="form-control me-2" type="date" placeholder="Pilih Tanggal" aria-label="Search by Date" name="tanggal" value="<?php echo htmlentities($this->input->get('tanggal')); ?>">
                <input class="form-control me-2" type="search" placeholder="Cari Data Nama/NoWA" aria-label="Search by Name/NoWA" name="search" value="<?php echo htmlentities($this->input->get('search')); ?>">
                <select class="form-select me-2" aria-label="Search by Status" name="status">
                    <option value="">Pilih Status</option>
                    <option value="belum ada akun" <?php echo $this->input->get('status') === 'belum ada akun' ? 'selected' : ''; ?>>Belum Ada Akun</option>
                    <option value="sudah ada akun" <?php echo $this->input->get('status') === 'sudah ada akun' ? 'selected' : ''; ?>>Sudah Ada Akun</option>
                </select>
                <button class="btn btn-outline-success" type="submit">Cari!</button>
            </form>
        </div>
    </nav>

    <!-- Table Section -->
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Id Registrasi</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>No WA</th>
                    <th>Status</th>
                    <th>Tgl Validasi</th>
                    <th>Tindakan</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = $offset + 1; foreach($valid as $p) { 
                    $is_disabled = ($p->status == 'sudah ada akun') ? 'disabled' : '';
                    $btn_class = ($p->status == 'sudah ada akun') ? 'btn-secondary' : 'btn-danger';
                    $create_btn_class = ($p->status == 'sudah ada akun') ? 'btn-secondary' : 'btn-success';
                ?>
                <tr>
                    <td><?php echo $no++;?></td>
                    <td><?php echo $p->id_registrasi; ?></td>
                    <td><?php echo $p->nama; ?></td>
                    <td><?php echo $p->email; ?></td>
                    <td><a href="<?php echo $p->no_wa; ?>"><?php echo $p->no_wa; ?></a></td>
                    <td style="color: <?php echo ($p->status == 'belum ada akun') ? 'red' : 'green'; ?>"><?php echo htmlentities($p->status); ?></td>
                    <td><?php echo $p->tgl_validasi; ?></td>
                    <td>
                        <div class="d-grid gap-2 d-md-flex justify-content-md-start">
                            <button class="btn <?php echo $btn_class; ?> btn-sm me-md-2 mb-2 mb-md-0 batal-validasi" data-id="<?php echo $p->id_validasi; ?>" data-registrasi="<?php echo $p->id_registrasi; ?>" type="button" <?php echo $is_disabled; ?>>Batal Validasi!</button>
                            <button class="btn <?php echo $create_btn_class; ?> btn-sm buat-akun" data-id="<?php echo $p->id_validasi; ?>" type="button" <?php echo $is_disabled; ?>>Buat Akun!</button>
                        </div>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination Links -->
    <div class="pagination-links">
        <?php echo $this->pagination->create_links(); ?>
    </div>
</div>

<!-- JavaScript untuk SweetAlert dan aksi batal validasi -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.3/dist/sweetalert2.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Handle batal validasi button click
        const batalBtns = document.querySelectorAll('.batal-validasi');
        batalBtns.forEach(btn => {
            btn.addEventListener('click', function () {
                const id_validasi = this.getAttribute('data-id');
                const id_registrasi = this.getAttribute('data-registrasi');

                // Tampilkan konfirmasi SweetAlert
                Swal.fire({
                    title: 'Apakah Anda yakin?',
                    text: "Data ini akan dibatalkan validasinya!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Ya, batalkan!',
                    cancelButtonText: 'Tidak, batal!',
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Lakukan request untuk batal validasi
                        fetch('<?php echo base_url('admin/batal_validasi/'); ?>' + id_validasi + '/' + id_registrasi)
                            .then(response => response.json())
                            .then(data => {
                                if (data.success) {
                                    Swal.fire(
                                        'Dibatalkan!',
                                        'Validasi telah dibatalkan.',
                                        'success'
                                    ).then(() => {
                                        location.reload(); // Reload halaman setelah menutup SweetAlert
                                    });
                                } else {
                                    Swal.fire(
                                        'Gagal!',
                                        'Terjadi kesalahan saat membatalkan validasi.',
                                        'error'
                                    );
                                }
                            });
                    }
                });
            });
        });

        // Handle buat akun button click
        const buatAkunBtns = document.querySelectorAll('.buat-akun');
        buatAkunBtns.forEach(btn => {
            btn.addEventListener('click', function () {
                const id_validasi = this.getAttribute('data-id');

                // Tampilkan konfirmasi SweetAlert
                Swal.fire({
                    title: 'Apakah Anda yakin?',
                    text: "Akun akan dibuat untuk pengguna ini!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Ya, buat akun!',
                    cancelButtonText: 'Tidak, batal!',
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Lakukan request untuk buat akun
                        fetch('<?php echo base_url('admin/buat_akun/'); ?>' + id_validasi, {
                            method: 'POST'
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                Swal.fire(
                                    'Berhasil!',
                                    data.message,
                                    'success'
                                ).then(() => {
                                    // Disable tombol dan ubah warna teks status
                                    btn.disabled = true;
                                    const row = btn.closest('tr');
                                    const batalBtn = row.querySelector('.batal-validasi');
                                    batalBtn.disabled = true;
                                    batalBtn.classList.remove('btn-danger');
                                    batalBtn.classList.add('btn-secondary');
                                    btn.classList.remove('btn-success');
                                    btn.classList.add('btn-secondary');
                                    const statusCell = row.querySelector('td:nth-child(6)');
                                    statusCell.innerHTML = '<span class="text-success">Sudah Ada Akun</span>';
                                });
                            } else {
                                Swal.fire(
                                    'Gagal!',
                                    data.message,
                                    'error'
                                );
                            }
                        });
                    }
                });
            });
        });
    });
</script>
