

   <!-- application/views/admin/v_registrasi.php -->

<div class="container mt-5 mb-5">
    <hr>
    <center>
        <p class="display-6 mb-3">Data Pendaftar Webinar Yang Belum Tervalidasi</p>
        <p class=" my-3">Total Pendaftar <?php echo $this->m_data->ambil_data('tb_registrasi')->num_rows(); ?></p>
        <p class=" my-3">Total Valid: <?php echo $total_valid; ?></p>
        <p class=" my-3">Total Invalid: <?php echo $total_invalid; ?></p>
        <marquee>
            <p class="mb-3">Acara yang berlangsung ENT Webinar Series Faring Laring-1</p>
        </marquee>
    </center>
    <hr>
</div>

<!-- Main Content -->
<div class="container">
    <!-- Search Bar -->
    <nav class="navbar bg-light mb-4">
        <div class="container-fluid">
            <form class="d-flex" role="search" method="get" action="<?php echo base_url('admin/registrasi'); ?>">
                <input class="form-control me-2" type="date" placeholder="Pilih Tanggal" aria-label="Search by Date"
                    name="tanggal" value="<?php echo htmlentities($this->input->get('tanggal')); ?>">
                <input class="form-control me-2" type="search" placeholder="Cari Data Nama/NoWA"
                    aria-label="Search by Name/NoWA" name="search"
                    value="<?php echo htmlentities($this->input->get('search')); ?>">
                <select class="form-select me-2" name="status">
                    <option value="">Pilih Status Validasi</option>
                    <option value="valid" <?php echo ($this->input->get('status') == 'valid') ? 'selected' : ''; ?>>
                        Valid
                    </option>
                    <option value="invalid"
                        <?php echo ($this->input->get('status') == 'invalid') ? 'selected' : ''; ?>>
                        Invalid
                    </option>
                </select>
                <button class="btn btn-outline-success" type="submit">Cari!</button>
            </form>
        </div>
    </nav>

    <!-- Table Section -->
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Pilihan</th>
                    <th>Nama</th>
                    <th>TTL</th>
                    <th>Profesi</th>
                    <th>Alamat</th>
                    <th>No WA</th>
                    <th>Email</th>
                    <th>Tgl Reg</th>
                    <th>Status</th>
                    <th>Bukti TF</th>
                    <th>Validasi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = $offset + 1; foreach($peserta as $index => $p) { ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo htmlentities($p->pilihan); ?></td>
                    <td><?php echo htmlentities($p->nama_gelar); ?></td>
                    <td><?php echo htmlentities($p->ttl); ?></td>
                    <td><?php echo htmlentities($p->profesi); ?></td>
                    <td>
                        <?php
                            $alamat = htmlentities($p->alamat);
                            $limit = 25; // Batas karakter untuk tampilan pendek
                            if (strlen($alamat) > $limit) {
                                // Jika lebih dari batas karakter, tampilkan versi pendek
                                $short_text = substr($alamat, 0, $limit) . '...';
                                echo '<span class="short-text">' . $short_text . '</span>';
                                echo '<span class="full-text d-none">' . $alamat . '</span>';
                                echo '<a href="#" class="read-more text-decoration-none">selengkapnya</a>';
                            } else {
                                // Jika tidak, tampilkan teks penuh
                                echo $alamat;
                            }
                        ?>
                    </td>
                    <td><a href="<?php echo($p->no_wa); ?>"><?php echo htmlentities($p->no_wa); ?></a></td>
                    <td><a href="mailto:<?php echo htmlentities($p->email); ?>"><?php echo htmlentities($p->email); ?></a></td>
                    <td><?php echo htmlentities($p->tgl_registrasi); ?></td>
                    <td style="color: <?php echo ($p->status == 'invalid') ? 'red' : 'blue'; ?>"><?php echo htmlentities($p->status); ?></td>
                    <td>
                        <?php if(!empty($p->bukti_tf)) { ?>
                        <a href="#" class="data-pdf-link"
                            data-pdf="<?php echo base_url('path/' . $p->bukti_tf); ?>"
                            data-bs-toggle="modal" data-bs-target="#buktiTfModal">Lihat Bukti TF</a>
                        <?php } else { echo 'No PDF'; } ?>
                    </td>
                    <td>
                        <?php if($p->status == 'invalid') { ?>
                        <a href="<?php echo base_url('admin/validasi/' . $p->id_registrasi); ?>"
                            class="btn btn-primary validasi-btn">Validasikan</a>
                        <?php } else { ?>
                        <button class="btn btn-secondary" type="button" disabled>Validasi Telah Dilakukan</button>
                        <?php } ?>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination Links -->
    <div class="pagination-links">
        <?php echo $this->pagination->create_links(); ?>
    </div>
</div>


    <!-- Modal untuk bukti TF dan PDF -->
    <div class="modal fade" id="buktiTfModal" tabindex="-1" aria-labelledby="buktiTfModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="buktiTfModalLabel">Dokumen Bukti Transfer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <div id="pdfContainer">
                        <embed src="" id="pdfEmbed" type="application/pdf" width="100%" height="600px" />
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- JavaScript untuk SweetAlert dan tampilan SweetAlert -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.3/dist/sweetalert2.min.js"></script>
    <script>
        // Tampilkan SweetAlert setelah berhasil memvalidasi data
        document.addEventListener('DOMContentLoaded', function() {
            const validasiBtns = document.querySelectorAll('.validasi-btn');
            validasiBtns.forEach(btn => {
                btn.addEventListener('click', function(event) {
                    event.preventDefault();
                    const url = this.getAttribute('href');

                    // Lakukan request untuk validasi data
                    fetch(url)
                        .then(response => response.json())
                        .then(data => {
                            // Tampilkan SweetAlert untuk memberi informasi bahwa validasi berhasil
                            if (data.success) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Berhasil!',
                                    text: 'Data telah divalidasi.'
                                }).then(() => {
                                    location.reload(); // Reload halaman setelah menutup SweetAlert
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Gagal!',
                                    text: 'Terjadi kesalahan saat memvalidasi data.'
                                });
                            }
                        })
                        .catch(error => {
                            Swal.fire({
                                    icon: 'success',
                                    title: 'Berhasil!',
                                    text: 'Data telah divalidasi.'
                                }).then(() => {
                                    location.reload(); // Reload halaman setelah menutup SweetAlert
                                });
                        });
                });
            });

            // Tampilkan bukti transfer atau PDF dalam modal
            const links = document.querySelectorAll('.data-pdf-link');
            const modal = new bootstrap.Modal(document.getElementById('buktiTfModal'), {
                keyboard: false
            });

            links.forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    const pdfSrc = this.getAttribute('data-pdf');
                    const pdfEmbed = document.getElementById('pdfEmbed');
                    pdfEmbed.src = pdfSrc;
                    modal.show();
                });
            });

            // Handle read more/less functionality for long addresses
            const readMores = document.querySelectorAll('.read-more');
            readMores.forEach(readMore => {
                readMore.addEventListener('click', function(e) {
                    e.preventDefault();
                    const fullText = this.parentElement.querySelector('.full-text');
                    const shortText = this.parentElement.querySelector('.short-text');
                    fullText.classList.toggle('d-none');
                    shortText.classList.toggle('d-none');
                    if (this.innerText === 'selengkapnya') {
                        this.innerText = 'kecilkan';
                    } else {
                        this.innerText = 'selengkapnya';
                    }
                });
            });
        });
    </script>

    <!-- Bootstrap Bundle dengan Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"></script>
</body>

</html>
