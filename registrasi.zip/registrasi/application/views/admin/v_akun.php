<!-- application/views/admin/v_akun.php -->

<div class="container mt-5 mb-5">
    <hr>
    <center>
        <p class="display-6 mb-3">Data Akun Pendaftar Webinar Yang Telah Tervalidasi</p>
         <p class=" my-3">Total Pendaftar <?php echo $this->m_data->ambil_data('tb_registrasi')->num_rows(); ?></p>
        <marquee>
            <p class="mb-3">Acara yang berlangsung ENT Webinar Series Faring Laring-1</p>
        </marquee>
    </center>
    <hr>
</div>

<!-- Main Content -->
<div class="container">
    <!-- Search Bar -->
    <nav class="navbar bg-light mb-4">
        <div class="container-fluid">
            <form class="d-flex" role="search" method="get" action="<?php echo base_url('admin/akun'); ?>">
                <input class="form-control me-2" type="search" placeholder="Cari Data Nama/NoWA" aria-label="Search by Name/NoWA" name="search" value="<?php echo htmlentities($this->input->get('search')); ?>">
                <button class="btn btn-outline-success" type="submit">Cari!</button>
            </form>
        </div>
    </nav>

    <!-- Table Section -->
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Level</th>
                    <th>Tindakan</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = + 1; foreach($akun as $p) { ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo $p->nama; ?></td>
                    <td><?php echo $p->email; ?></td>
                    <td><?php echo $p->level; ?></td>
                    <td>
                        <div class="d-grid gap-2 d-md-flex justify-content-md-start">
                            <button class="btn btn-warning btn-sm update-akun" data-id="<?php echo $p->id_user; ?>" data-email="<?php echo $p->email; ?>" type="button">Update</button>
                            <button class="btn btn-danger btn-sm hapus-akun" data-id="<?php echo $p->id_user; ?>" type="button">Hapus</button>
                        </div>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination Links -->
    <?php if(count($akun) > 5) { ?>
    <nav aria-label="Page navigation example">
        <ul class="pagination">
            <?php echo $this->pagination->create_links(); ?>
        </ul>
    </nav>
    <?php } ?>
</div>

<!-- Modal for Update Data -->
<div class="modal fade" id="updateModal" tabindex="-1" aria-labelledby="updateModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="updateModalLabel">Update Data Akun</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="updateForm">
                    <input type="hidden" id="updateId" name="id">
                    <div class="mb-3">
                        <label for="updateEmail" class="form-label">Email</label>
                        <input type="email" class="form-control" id="updateEmail" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="updatePassword" class="form-label">Password</label>
                        <input type="password" class="form-control" id="updatePassword" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Update</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Script Section -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.3/dist/sweetalert2.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Handle delete button click
        const hapusBtns = document.querySelectorAll('.hapus-akun');
        hapusBtns.forEach(btn => {
            btn.addEventListener('click', function () {
                const id = this.getAttribute('data-id');

                // Tampilkan konfirmasi SweetAlert
                Swal.fire({
                    title: 'Apakah Anda yakin?',
                    text: "Data akun ini akan dihapus!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Ya, hapus!',
                    cancelButtonText: 'Tidak, batal!',
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Lakukan request untuk hapus akun
                        fetch('<?php echo base_url('admin/hapus_akun/'); ?>' + id)
                            .then(response => response.json())
                            .then(data => {
                                if (data.success) {
                                    Swal.fire(
                                        'Dihapus!',
                                        'Akun telah dihapus.',
                                        'success'
                                    ).then(() => {
                                        location.reload(); // Reload halaman setelah menutup SweetAlert
                                    });
                                } else {
                                    Swal.fire(
                                        'Gagal!',
                                        'Terjadi kesalahan saat menghapus akun.',
                                        'error'
                                    );
                                }
                            });
                    }
                });
            });
        });

        // Handle update button click
        const updateBtns = document.querySelectorAll('.update-akun');
        updateBtns.forEach(btn => {
            btn.addEventListener('click', function () {
                const id = this.getAttribute('data-id');
                const email = this.getAttribute('data-email');

                // Isi form dengan data yang ada
                document.getElementById('updateId').value = id;
                document.getElementById('updateEmail').value = email;

                // Tampilkan modal
                new bootstrap.Modal(document.getElementById('updateModal')).show();
            });
        });

        // Handle form submit for update
        document.getElementById('updateForm').addEventListener('submit', function (e) {
            e.preventDefault();
            const formData = new FormData(this);

            fetch('<?php echo base_url('admin/update_akun'); ?>', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire(
                        'Berhasil!',
                        'Data akun berhasil diperbarui.',
                        'success'
                    ).then(() => {
                        location.reload(); // Reload halaman setelah menutup SweetAlert
                    });
                } else {
                    Swal.fire(
                        'Gagal!',
                        'Terjadi kesalahan saat memperbarui data akun.',
                        'error'
                    );
                }
            });
        });
    });
</script>
