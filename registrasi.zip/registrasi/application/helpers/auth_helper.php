<?php
defined('BASEPATH') OR exit('No direct script access allowed');

if (!function_exists('check_login')) {
    function check_login() {
        $CI =& get_instance(); // Get the instance of the CodeIgniter super object
        if (!$CI->session->userdata('id_user')) { // Check if the user session data exists
            redirect('auth/masuk'); // Redirect to the login page if the user is not logged in
        }
    }
}
?>
